import os
import tempfile
import subprocess
import json
import uuid
from datetime import datetime
from io import BytesIO
import re

from flask import Flask, request, jsonify, send_file, render_template_string
from flask_cors import CORS

# Importações para processamento de documentos
try:
    import PyPDF2
    import docx
    HAS_ADVANCED_IMPORTS = True
except ImportError:
    HAS_ADVANCED_IMPORTS = False

app = Flask(__name__)
CORS(app)  # Habilitar CORS para todas as rotas
app.config['SECRET_KEY'] = 'proposal-analyzer-pro-secret-key-2025'
app.config['MAX_CONTENT_LENGTH'] = 50 * 1024 * 1024  # Limite de 50MB para uploads

# Diretório para armazenar uploads temporários
UPLOAD_FOLDER = os.path.join(os.path.dirname(__file__), 'uploads')
if not os.path.exists(UPLOAD_FOLDER):
    os.makedirs(UPLOAD_FOLDER)

# HTML da interface
HTML_TEMPLATE = '''<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Proposal Analyzer Pro</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <style>
        :root {
            --primary-color: #4a6bff;
            --primary-dark: #3451c7;
            --secondary-color: #ff6b6b;
            --success-color: #28a745;
            --warning-color: #ffc107;
            --danger-color: #dc3545;
            --light-color: #f8f9fa;
            --dark-color: #343a40;
            --gray-color: #6c757d;
            --border-radius: 10px;
            --box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
            --transition: all 0.3s ease;
        }

        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background: linear-gradient(135deg, #f5f7fa 0%, #c3cfe2 100%);
            min-height: 100vh;
            color: #333;
            line-height: 1.6;
        }

        .header {
            background: linear-gradient(135deg, #4a6bff 0%, #3451c7 100%);
            color: white;
            padding: 2rem 0;
            text-align: center;
            box-shadow: var(--box-shadow);
        }

        .header h1 {
            font-size: 2.5rem;
            margin-bottom: 0.5rem;
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 1rem;
        }

        .header p {
            font-size: 1.2rem;
            opacity: 0.9;
        }

        .container {
            max-width: 1200px;
            margin: 0 auto;
            padding: 2rem;
        }

        .info-section {
            background: white;
            border-radius: var(--border-radius);
            padding: 2rem;
            margin-bottom: 2rem;
            box-shadow: var(--box-shadow);
        }

        .info-section h2 {
            color: var(--primary-color);
            margin-bottom: 1rem;
            display: flex;
            align-items: center;
            gap: 0.5rem;
        }

        .features {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
            gap: 1.5rem;
            margin: 2rem 0;
        }

        .feature {
            background: white;
            padding: 1.5rem;
            border-radius: var(--border-radius);
            text-align: center;
            box-shadow: var(--box-shadow);
            transition: var(--transition);
        }

        .feature:hover {
            transform: translateY(-5px);
            box-shadow: 0 8px 15px rgba(0, 0, 0, 0.15);
        }

        .feature i {
            font-size: 3rem;
            color: var(--primary-color);
            margin-bottom: 1rem;
        }

        .feature h3 {
            color: var(--dark-color);
            margin-bottom: 0.5rem;
        }

        .form-section {
            background: white;
            border-radius: var(--border-radius);
            padding: 2rem;
            margin-bottom: 2rem;
            box-shadow: var(--box-shadow);
        }

        .form-group {
            margin-bottom: 1.5rem;
        }

        .form-group label {
            display: block;
            margin-bottom: 0.5rem;
            font-weight: 600;
            color: var(--dark-color);
        }

        .form-group input,
        .form-group textarea {
            width: 100%;
            padding: 0.75rem;
            border: 2px solid #e9ecef;
            border-radius: var(--border-radius);
            font-size: 1rem;
            transition: var(--transition);
        }

        .form-group input:focus,
        .form-group textarea:focus {
            outline: none;
            border-color: var(--primary-color);
            box-shadow: 0 0 0 3px rgba(74, 107, 255, 0.1);
        }

        .file-upload {
            position: relative;
            display: inline-block;
            cursor: pointer;
            width: 100%;
        }

        .file-upload input[type="file"] {
            position: absolute;
            opacity: 0;
            width: 100%;
            height: 100%;
            cursor: pointer;
        }

        .file-upload-label {
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 0.5rem;
            padding: 1rem;
            border: 2px dashed var(--primary-color);
            border-radius: var(--border-radius);
            background: rgba(74, 107, 255, 0.05);
            color: var(--primary-color);
            font-weight: 600;
            transition: var(--transition);
        }

        .file-upload:hover .file-upload-label {
            background: rgba(74, 107, 255, 0.1);
            border-color: var(--primary-dark);
        }

        .btn {
            display: inline-flex;
            align-items: center;
            gap: 0.5rem;
            padding: 0.75rem 1.5rem;
            border: none;
            border-radius: var(--border-radius);
            font-size: 1rem;
            font-weight: 600;
            text-decoration: none;
            cursor: pointer;
            transition: var(--transition);
        }

        .btn-primary {
            background: var(--primary-color);
            color: white;
        }

        .btn-primary:hover {
            background: var(--primary-dark);
            transform: translateY(-2px);
        }

        .btn-success {
            background: var(--success-color);
            color: white;
        }

        .btn-success:hover {
            background: #218838;
            transform: translateY(-2px);
        }

        .btn-secondary {
            background: var(--gray-color);
            color: white;
        }

        .btn-secondary:hover {
            background: #5a6268;
        }

        .btn-large {
            padding: 1rem 2rem;
            font-size: 1.2rem;
            width: 100%;
            justify-content: center;
        }

        .proposal-section {
            border: 2px solid #e9ecef;
            border-radius: var(--border-radius);
            padding: 1.5rem;
            margin-bottom: 1rem;
            background: #f8f9fa;
        }

        .proposal-section h4 {
            color: var(--primary-color);
            margin-bottom: 1rem;
            display: flex;
            align-items: center;
            gap: 0.5rem;
        }

        .add-proposal {
            text-align: center;
            padding: 1rem;
            border: 2px dashed var(--gray-color);
            border-radius: var(--border-radius);
            margin-bottom: 1rem;
            cursor: pointer;
            transition: var(--transition);
        }

        .add-proposal:hover {
            border-color: var(--primary-color);
            background: rgba(74, 107, 255, 0.05);
        }

        .loading {
            display: none;
            text-align: center;
            padding: 2rem;
        }

        .loading i {
            font-size: 3rem;
            color: var(--primary-color);
            animation: spin 1s linear infinite;
        }

        @keyframes spin {
            0% { transform: rotate(0deg); }
            100% { transform: rotate(360deg); }
        }

        .result {
            display: none;
            background: white;
            border-radius: var(--border-radius);
            padding: 2rem;
            margin-top: 2rem;
            box-shadow: var(--box-shadow);
        }

        .result h3 {
            color: var(--success-color);
            margin-bottom: 1rem;
            display: flex;
            align-items: center;
            gap: 0.5rem;
        }

        .download-buttons {
            display: flex;
            gap: 1rem;
            margin-top: 1rem;
        }

        .error {
            background: #f8d7da;
            color: #721c24;
            padding: 1rem;
            border-radius: var(--border-radius);
            margin: 1rem 0;
            border: 1px solid #f5c6cb;
        }

        @media (max-width: 768px) {
            .container {
                padding: 1rem;
            }
            
            .header h1 {
                font-size: 2rem;
            }
            
            .features {
                grid-template-columns: 1fr;
            }
            
            .download-buttons {
                flex-direction: column;
            }
        }
    </style>
</head>
<body>
    <div class="header">
        <h1>
            <i class="fas fa-chart-line"></i>
            Proposal Analyzer Pro
        </h1>
        <p>Sistema Avançado de Análise de Propostas</p>
    </div>

    <div class="container">
        <div class="info-section">
            <h2><i class="fas fa-info-circle"></i> Sobre o Sistema</h2>
            <p>O <strong>Proposal Analyzer Pro</strong> é um sistema avançado para análise e comparação de propostas técnicas e comerciais, verificando a aderência ao Termo de Referência. Utilizando tecnologias de processamento de documentos e análise de dados, o sistema gera relatórios detalhados que auxiliam na tomada de decisão.</p>
            
            <div class="features">
                <div class="feature">
                    <i class="fas fa-file-alt"></i>
                    <h3>Análise de TR</h3>
                    <p>Extração e análise dos requisitos principais do Termo de Referência</p>
                </div>
                <div class="feature">
                    <i class="fas fa-tools"></i>
                    <h3>Propostas Técnicas</h3>
                    <p>Avaliação de metodologia, cronograma, equipe e materiais</p>
                </div>
                <div class="feature">
                    <i class="fas fa-dollar-sign"></i>
                    <h3>Propostas Comerciais</h3>
                    <p>Análise de preços, BDI e condições de pagamento</p>
                </div>
                <div class="feature">
                    <i class="fas fa-chart-bar"></i>
                    <h3>Relatórios Detalhados</h3>
                    <p>Geração de relatórios comparativos em PDF e Markdown</p>
                </div>
            </div>
        </div>

        <form id="analysisForm" enctype="multipart/form-data">
            <div class="form-section">
                <h2><i class="fas fa-project-diagram"></i> Dados do Projeto</h2>
                
                <div class="form-group">
                    <label for="projectName">Nome do Projeto *</label>
                    <input type="text" id="projectName" name="projectName" required placeholder="Digite o nome do projeto">
                </div>
                
                <div class="form-group">
                    <label for="projectDescription">Descrição</label>
                    <textarea id="projectDescription" name="projectDescription" rows="3" placeholder="Descrição opcional do projeto"></textarea>
                </div>
            </div>

            <div class="form-section">
                <h2><i class="fas fa-file-contract"></i> Termo de Referência (TR)</h2>
                
                <div class="form-group">
                    <label>Arquivo do TR</label>
                    <div class="file-upload">
                        <input type="file" id="trFile" name="trFile" accept=".pdf,.doc,.docx,.ppt,.pptx,.zip">
                        <div class="file-upload-label">
                            <i class="fas fa-upload"></i>
                            📄 Clique para selecionar o arquivo do TR
                        </div>
                    </div>
                    <small>Aceita: PDF, DOC, DOCX, PPT, PPTX, ZIP</small>
                </div>
            </div>

            <div class="form-section">
                <h2><i class="fas fa-cogs"></i> Propostas Técnicas</h2>
                <div id="technicalProposals">
                    <div class="proposal-section">
                        <h4><i class="fas fa-building"></i> Empresa 1</h4>
                        <div class="form-group">
                            <label>Nome da Empresa</label>
                            <input type="text" name="techCompany1" placeholder="Nome da empresa">
                        </div>
                        <div class="form-group">
                            <label>Arquivo da Proposta</label>
                            <div class="file-upload">
                                <input type="file" name="techFile1" accept=".pdf,.doc,.docx,.ppt,.pptx,.zip">
                                <div class="file-upload-label">
                                    <i class="fas fa-upload"></i>
                                    📁 Selecionar arquivo
                                </div>
                            </div>
                            <small>PDF, DOC, DOCX, PPT, PPTX, ZIP</small>
                        </div>
                    </div>
                </div>
                <div class="add-proposal" onclick="addTechnicalProposal()">
                    <i class="fas fa-plus"></i> Adicionar Proposta Técnica
                </div>
            </div>

            <div class="form-section">
                <h2><i class="fas fa-money-bill-wave"></i> Propostas Comerciais</h2>
                <div id="commercialProposals">
                    <div class="proposal-section">
                        <h4><i class="fas fa-building"></i> Empresa 1</h4>
                        <div class="form-group">
                            <label>Nome da Empresa</label>
                            <input type="text" name="commCompany1" placeholder="Nome da empresa">
                        </div>
                        <div class="form-group">
                            <label>CNPJ (opcional)</label>
                            <input type="text" name="commCnpj1" placeholder="00.000.000/0000-00">
                        </div>
                        <div class="form-group">
                            <label>Arquivo da Proposta Comercial</label>
                            <div class="file-upload">
                                <input type="file" name="commFile1" accept=".pdf,.doc,.docx,.xls,.xlsx,.zip">
                                <div class="file-upload-label">
                                    <i class="fas fa-upload"></i>
                                    💰 Selecionar arquivo
                                </div>
                            </div>
                            <small>PDF, DOC, DOCX, XLS, XLSX, ZIP</small>
                        </div>
                    </div>
                </div>
                <div class="add-proposal" onclick="addCommercialProposal()">
                    <i class="fas fa-plus"></i> Adicionar Proposta Comercial
                </div>
            </div>

            <div class="form-section">
                <button type="submit" class="btn btn-primary btn-large">
                    <i class="fas fa-rocket"></i>
                    Gerar Relatório com Análise IA
                </button>
            </div>
        </form>

        <div class="loading" id="loading">
            <i class="fas fa-spinner"></i>
            <h3>Processando documentos...</h3>
            <p>Aguarde enquanto analisamos suas propostas</p>
        </div>

        <div class="result" id="result">
            <h3><i class="fas fa-check-circle"></i> Relatório Gerado com Sucesso!</h3>
            <p>Seu relatório de análise foi gerado e está pronto para download.</p>
            <div class="download-buttons">
                <a href="#" id="downloadMarkdown" class="btn btn-success">
                    <i class="fas fa-download"></i> Download Markdown
                </a>
                <a href="#" id="downloadPdf" class="btn btn-secondary">
                    <i class="fas fa-file-pdf"></i> Download PDF
                </a>
            </div>
        </div>
    </div>

    <script>
        let techProposalCount = 1;
        let commProposalCount = 1;

        function addTechnicalProposal() {
            if (techProposalCount >= 4) {
                alert('Máximo de 4 propostas técnicas permitidas');
                return;
            }
            
            techProposalCount++;
            const container = document.getElementById('technicalProposals');
            const proposalHtml = `
                <div class="proposal-section">
                    <h4><i class="fas fa-building"></i> Empresa ${techProposalCount}</h4>
                    <div class="form-group">
                        <label>Nome da Empresa</label>
                        <input type="text" name="techCompany${techProposalCount}" placeholder="Nome da empresa">
                    </div>
                    <div class="form-group">
                        <label>Arquivo da Proposta</label>
                        <div class="file-upload">
                            <input type="file" name="techFile${techProposalCount}" accept=".pdf,.doc,.docx,.ppt,.pptx,.zip">
                            <div class="file-upload-label">
                                <i class="fas fa-upload"></i>
                                📁 Selecionar arquivo
                            </div>
                        </div>
                        <small>PDF, DOC, DOCX, PPT, PPTX, ZIP</small>
                    </div>
                </div>
            `;
            container.insertAdjacentHTML('beforeend', proposalHtml);
        }

        function addCommercialProposal() {
            if (commProposalCount >= 4) {
                alert('Máximo de 4 propostas comerciais permitidas');
                return;
            }
            
            commProposalCount++;
            const container = document.getElementById('commercialProposals');
            const proposalHtml = `
                <div class="proposal-section">
                    <h4><i class="fas fa-building"></i> Empresa ${commProposalCount}</h4>
                    <div class="form-group">
                        <label>Nome da Empresa</label>
                        <input type="text" name="commCompany${commProposalCount}" placeholder="Nome da empresa">
                    </div>
                    <div class="form-group">
                        <label>CNPJ (opcional)</label>
                        <input type="text" name="commCnpj${commProposalCount}" placeholder="00.000.000/0000-00">
                    </div>
                    <div class="form-group">
                        <label>Arquivo da Proposta Comercial</label>
                        <div class="file-upload">
                            <input type="file" name="commFile${commProposalCount}" accept=".pdf,.doc,.docx,.xls,.xlsx,.zip">
                            <div class="file-upload-label">
                                <i class="fas fa-upload"></i>
                                💰 Selecionar arquivo
                            </div>
                        </div>
                        <small>PDF, DOC, DOCX, XLS, XLSX, ZIP</small>
                    </div>
                </div>
            `;
            container.insertAdjacentHTML('beforeend', proposalHtml);
        }

        // Atualizar labels dos arquivos quando selecionados
        document.addEventListener('change', function(e) {
            if (e.target.type === 'file') {
                const label = e.target.nextElementSibling;
                if (e.target.files.length > 0) {
                    label.innerHTML = `<i class="fas fa-check"></i> ${e.target.files[0].name}`;
                    label.style.background = 'rgba(40, 167, 69, 0.1)';
                    label.style.borderColor = '#28a745';
                    label.style.color = '#28a745';
                }
            }
        });

        // Submissão do formulário
        document.getElementById('analysisForm').addEventListener('submit', async function(e) {
            e.preventDefault();
            
            const formData = new FormData(this);
            const loading = document.getElementById('loading');
            const result = document.getElementById('result');
            
            // Mostrar loading
            loading.style.display = 'block';
            result.style.display = 'none';
            
            try {
                const response = await fetch('/analyze', {
                    method: 'POST',
                    body: formData
                });
                
                const data = await response.json();
                
                if (data.success) {
                    // Configurar links de download
                    document.getElementById('downloadMarkdown').href = `/download/${data.report_id}/markdown`;
                    document.getElementById('downloadPdf').href = `/download/${data.report_id}/pdf`;
                    
                    // Mostrar resultado
                    loading.style.display = 'none';
                    result.style.display = 'block';
                    
                    // Scroll para o resultado
                    result.scrollIntoView({ behavior: 'smooth' });
                } else {
                    throw new Error(data.error || 'Erro desconhecido');
                }
            } catch (error) {
                loading.style.display = 'none';
                alert('Erro ao processar: ' + error.message);
            }
        });
    </script>
</body>
</html>'''

# Classe para análise de documentos (versão simplificada)
class DocumentAnalyzer:
    def __init__(self):
        self.technical_keywords = [
            'metodologia', 'cronograma', 'equipe', 'prazo', 'execução',
            'mão de obra', 'equipamentos', 'materiais', 'especificação',
            'técnica', 'qualificação', 'experiência', 'certificação'
        ]
        self.commercial_keywords = [
            'preço', 'valor', 'custo', 'bdi', 'lucro', 'administração',
            'impostos', 'encargos', 'pagamento', 'desconto', 'reajuste'
        ]
    
    def extract_text_from_pdf(self, file_path):
        """Extrai texto de um arquivo PDF"""
        if not HAS_ADVANCED_IMPORTS:
            return "Análise de PDF não disponível - bibliotecas não instaladas"
        
        try:
            with open(file_path, 'rb') as file:
                pdf_reader = PyPDF2.PdfReader(file)
                text = ""
                
                for page in pdf_reader.pages:
                    page_text = page.extract_text()
                    if page_text:
                        text += page_text + "\n"
                
                return text
        except Exception as e:
            return f"Erro na extração do PDF: {str(e)}"
    
    def extract_text_from_docx(self, file_path):
        """Extrai texto de um arquivo DOCX"""
        if not HAS_ADVANCED_IMPORTS:
            return "Análise de DOCX não disponível - bibliotecas não instaladas"
        
        try:
            doc = docx.Document(file_path)
            text = ""
            
            for paragraph in doc.paragraphs:
                text += paragraph.text + "\n"
            
            # Extrair texto de tabelas
            for table in doc.tables:
                for row in table.rows:
                    for cell in row.cells:
                        text += cell.text + " "
                    text += "\n"
            
            return text
        except Exception as e:
            return f"Erro na extração do DOCX: {str(e)}"
    
    def analyze_document(self, file_path, doc_type):
        """Analisa um documento baseado em seu tipo"""
        file_ext = os.path.splitext(file_path)[1].lower()
        
        if file_ext == '.pdf':
            text = self.extract_text_from_pdf(file_path)
        elif file_ext in ['.docx', '.doc']:
            text = self.extract_text_from_docx(file_path)
        else:
            return {"error": f"Formato de arquivo não suportado: {file_ext}"}
        
        if text.startswith("Erro") or text.startswith("Análise"):
            return {"error": text}
        
        # Análise simplificada baseada no tipo de documento
        if doc_type == 'tr':
            return self.analyze_tr(text)
        elif doc_type == 'technical':
            return self.analyze_technical_proposal(text)
        elif doc_type == 'commercial':
            return self.analyze_commercial_proposal(text)
        else:
            return {"error": "Tipo de documento não reconhecido"}
    
    def analyze_tr(self, text):
        """Analisa o Termo de Referência"""
        analysis = {
            "tipo": "Termo de Referência",
            "requisitos_principais": [],
            "prazos": [],
            "especificacoes_tecnicas": [],
            "criterios_avaliacao": []
        }
        
        # Buscar requisitos principais
        lines = text.split('\n')
        for line in lines:
            line_lower = line.lower()
            if any(keyword in line_lower for keyword in ['requisito', 'obrigatório', 'deve', 'deverá']):
                if len(line.strip()) > 10:
                    analysis["requisitos_principais"].append(line.strip())
            
            if any(keyword in line_lower for keyword in ['prazo', 'cronograma', 'entrega']):
                if len(line.strip()) > 10:
                    analysis["prazos"].append(line.strip())
            
            if any(keyword in line_lower for keyword in self.technical_keywords):
                if len(line.strip()) > 10:
                    analysis["especificacoes_tecnicas"].append(line.strip())
        
        return analysis
    
    def analyze_technical_proposal(self, text):
        """Analisa uma proposta técnica"""
        analysis = {
            "tipo": "Proposta Técnica",
            "metodologia": [],
            "equipe": [],
            "cronograma": [],
            "materiais": [],
            "equipamentos": []
        }
        
        lines = text.split('\n')
        for line in lines:
            line_lower = line.lower()
            
            if any(keyword in line_lower for keyword in ['metodologia', 'método', 'abordagem']):
                if len(line.strip()) > 10:
                    analysis["metodologia"].append(line.strip())
            
            if any(keyword in line_lower for keyword in ['equipe', 'profissional', 'técnico', 'engenheiro']):
                if len(line.strip()) > 10:
                    analysis["equipe"].append(line.strip())
            
            if any(keyword in line_lower for keyword in ['cronograma', 'prazo', 'etapa']):
                if len(line.strip()) > 10:
                    analysis["cronograma"].append(line.strip())
            
            if any(keyword in line_lower for keyword in ['material', 'insumo', 'produto']):
                if len(line.strip()) > 10:
                    analysis["materiais"].append(line.strip())
            
            if any(keyword in line_lower for keyword in ['equipamento', 'máquina', 'ferramenta']):
                if len(line.strip()) > 10:
                    analysis["equipamentos"].append(line.strip())
        
        return analysis
    
    def analyze_commercial_proposal(self, text):
        """Analisa uma proposta comercial"""
        analysis = {
            "tipo": "Proposta Comercial",
            "precos": [],
            "bdi": [],
            "condicoes_pagamento": [],
            "custos_detalhados": []
        }
        
        lines = text.split('\n')
        for line in lines:
            line_lower = line.lower()
            
            if any(keyword in line_lower for keyword in ['preço', 'valor', 'total', 'r$']):
                if len(line.strip()) > 10:
                    analysis["precos"].append(line.strip())
            
            if any(keyword in line_lower for keyword in ['bdi', 'benefício', 'despesa']):
                if len(line.strip()) > 10:
                    analysis["bdi"].append(line.strip())
            
            if any(keyword in line_lower for keyword in ['pagamento', 'parcela', 'condição']):
                if len(line.strip()) > 10:
                    analysis["condicoes_pagamento"].append(line.strip())
            
            if any(keyword in line_lower for keyword in ['custo', 'mão de obra', 'material', 'equipamento']):
                if len(line.strip()) > 10:
                    analysis["custos_detalhados"].append(line.strip())
        
        return analysis

# Instância do analisador
analyzer = DocumentAnalyzer()

@app.route('/')
def index():
    """Página principal"""
    return render_template_string(HTML_TEMPLATE)

@app.route('/analyze', methods=['POST'])
def analyze():
    """Endpoint para análise de propostas"""
    try:
        # Gerar ID único para este relatório
        report_id = str(uuid.uuid4())
        
        # Obter dados do formulário
        project_name = request.form.get('projectName', '')
        project_description = request.form.get('projectDescription', '')
        
        if not project_name:
            return jsonify({"success": False, "error": "Nome do projeto é obrigatório"})
        
        # Processar arquivos
        tr_analysis = None
        technical_analyses = []
        commercial_analyses = []
        
        # Analisar TR
        if 'trFile' in request.files and request.files['trFile'].filename:
            tr_file = request.files['trFile']
            tr_path = os.path.join(UPLOAD_FOLDER, f"tr_{report_id}_{tr_file.filename}")
            tr_file.save(tr_path)
            tr_analysis = analyzer.analyze_document(tr_path, 'tr')
        
        # Analisar propostas técnicas
        for i in range(1, 5):  # Máximo 4 propostas
            company_key = f'techCompany{i}'
            file_key = f'techFile{i}'
            
            if company_key in request.form and file_key in request.files:
                company_name = request.form.get(company_key, '')
                tech_file = request.files[file_key]
                
                if company_name and tech_file.filename:
                    tech_path = os.path.join(UPLOAD_FOLDER, f"tech_{i}_{report_id}_{tech_file.filename}")
                    tech_file.save(tech_path)
                    analysis = analyzer.analyze_document(tech_path, 'technical')
                    analysis['empresa'] = company_name
                    technical_analyses.append(analysis)
        
        # Analisar propostas comerciais
        for i in range(1, 5):  # Máximo 4 propostas
            company_key = f'commCompany{i}'
            cnpj_key = f'commCnpj{i}'
            file_key = f'commFile{i}'
            
            if company_key in request.form and file_key in request.files:
                company_name = request.form.get(company_key, '')
                cnpj = request.form.get(cnpj_key, '')
                comm_file = request.files[file_key]
                
                if company_name and comm_file.filename:
                    comm_path = os.path.join(UPLOAD_FOLDER, f"comm_{i}_{report_id}_{comm_file.filename}")
                    comm_file.save(comm_path)
                    analysis = analyzer.analyze_document(comm_path, 'commercial')
                    analysis['empresa'] = company_name
                    analysis['cnpj'] = cnpj
                    commercial_analyses.append(analysis)
        
        # Gerar relatório
        report_content = generate_report(
            project_name, project_description, tr_analysis, 
            technical_analyses, commercial_analyses
        )
        
        # Salvar relatório
        report_path = os.path.join(UPLOAD_FOLDER, f"report_{report_id}.md")
        with open(report_path, 'w', encoding='utf-8') as f:
            f.write(report_content)
        
        return jsonify({
            "success": True, 
            "report_id": report_id,
            "message": "Relatório gerado com sucesso"
        })
        
    except Exception as e:
        return jsonify({"success": False, "error": str(e)})

@app.route('/download/<report_id>/<format>')
def download_report(report_id, format):
    """Download do relatório em diferentes formatos"""
    try:
        if format == 'markdown':
            report_path = os.path.join(UPLOAD_FOLDER, f"report_{report_id}.md")
            if os.path.exists(report_path):
                return send_file(report_path, as_attachment=True, download_name=f"relatorio_{report_id}.md")
        
        elif format == 'pdf':
            # Tentar converter para PDF
            md_path = os.path.join(UPLOAD_FOLDER, f"report_{report_id}.md")
            pdf_path = os.path.join(UPLOAD_FOLDER, f"report_{report_id}.pdf")
            
            if os.path.exists(md_path):
                try:
                    # Tentar usar o utilitário manus-md-to-pdf
                    result = subprocess.run([
                        'manus-md-to-pdf', md_path, pdf_path
                    ], capture_output=True, text=True, timeout=30)
                    
                    if result.returncode == 0 and os.path.exists(pdf_path):
                        return send_file(pdf_path, as_attachment=True, download_name=f"relatorio_{report_id}.pdf")
                    else:
                        # Se falhar, retornar o markdown
                        return send_file(md_path, as_attachment=True, download_name=f"relatorio_{report_id}.md")
                except:
                    # Se falhar, retornar o markdown
                    return send_file(md_path, as_attachment=True, download_name=f"relatorio_{report_id}.md")
        
        return jsonify({"error": "Formato não suportado"}), 400
        
    except Exception as e:
        return jsonify({"error": str(e)}), 500

def generate_report(project_name, project_description, tr_analysis, technical_analyses, commercial_analyses):
    """Gera o relatório final em Markdown"""
    
    report = f"""# Relatório de Análise de Propostas
## {project_name}

**Data da Análise:** {datetime.now().strftime('%d/%m/%Y %H:%M')}

"""
    
    if project_description:
        report += f"""**Descrição do Projeto:** {project_description}

"""
    
    # Análise do TR
    if tr_analysis:
        report += """## 📋 Análise do Termo de Referência

"""
        if 'requisitos_principais' in tr_analysis and tr_analysis['requisitos_principais']:
            report += """### Requisitos Principais Identificados:
"""
            for req in tr_analysis['requisitos_principais'][:5]:  # Limitar a 5 itens
                report += f"- {req}\n"
            report += "\n"
        
        if 'especificacoes_tecnicas' in tr_analysis and tr_analysis['especificacoes_tecnicas']:
            report += """### Especificações Técnicas:
"""
            for spec in tr_analysis['especificacoes_tecnicas'][:5]:  # Limitar a 5 itens
                report += f"- {spec}\n"
            report += "\n"
    
    # Análise das Propostas Técnicas
    if technical_analyses:
        report += """## 🔧 Análise das Propostas Técnicas

"""
        
        for i, analysis in enumerate(technical_analyses, 1):
            empresa = analysis.get('empresa', f'Empresa {i}')
            report += f"""### {empresa}

"""
            
            if 'metodologia' in analysis and analysis['metodologia']:
                report += """**Metodologia:**
"""
                for item in analysis['metodologia'][:3]:  # Limitar a 3 itens
                    report += f"- {item}\n"
                report += "\n"
            
            if 'equipe' in analysis and analysis['equipe']:
                report += """**Equipe:**
"""
                for item in analysis['equipe'][:3]:  # Limitar a 3 itens
                    report += f"- {item}\n"
                report += "\n"
            
            if 'cronograma' in analysis and analysis['cronograma']:
                report += """**Cronograma:**
"""
                for item in analysis['cronograma'][:3]:  # Limitar a 3 itens
                    report += f"- {item}\n"
                report += "\n"
    
    # Análise das Propostas Comerciais
    if commercial_analyses:
        report += """## 💰 Análise das Propostas Comerciais

"""
        
        for i, analysis in enumerate(commercial_analyses, 1):
            empresa = analysis.get('empresa', f'Empresa {i}')
            cnpj = analysis.get('cnpj', 'Não informado')
            
            report += f"""### {empresa}
**CNPJ:** {cnpj}

"""
            
            if 'precos' in analysis and analysis['precos']:
                report += """**Preços:**
"""
                for item in analysis['precos'][:3]:  # Limitar a 3 itens
                    report += f"- {item}\n"
                report += "\n"
            
            if 'bdi' in analysis and analysis['bdi']:
                report += """**BDI:**
"""
                for item in analysis['bdi'][:3]:  # Limitar a 3 itens
                    report += f"- {item}\n"
                report += "\n"
            
            if 'condicoes_pagamento' in analysis and analysis['condicoes_pagamento']:
                report += """**Condições de Pagamento:**
"""
                for item in analysis['condicoes_pagamento'][:3]:  # Limitar a 3 itens
                    report += f"- {item}\n"
                report += "\n"
    
    # Análise Comparativa
    if technical_analyses or commercial_analyses:
        report += """## 📊 Análise Comparativa

### Resumo das Propostas

| Empresa | Proposta Técnica | Proposta Comercial | Observações |
|---------|------------------|-------------------|-------------|
"""
        
        # Criar tabela comparativa
        all_companies = set()
        if technical_analyses:
            all_companies.update([analysis.get('empresa', f'Empresa {i+1}') for i, analysis in enumerate(technical_analyses)])
        if commercial_analyses:
            all_companies.update([analysis.get('empresa', f'Empresa {i+1}') for i, analysis in enumerate(commercial_analyses)])
        
        for company in all_companies:
            tech_status = "✅ Apresentada" if any(analysis.get('empresa') == company for analysis in technical_analyses) else "❌ Não apresentada"
            comm_status = "✅ Apresentada" if any(analysis.get('empresa') == company for analysis in commercial_analyses) else "❌ Não apresentada"
            
            # Verificar se tem CNPJ
            cnpj_info = ""
            for analysis in commercial_analyses:
                if analysis.get('empresa') == company and analysis.get('cnpj'):
                    cnpj_info = "CNPJ informado"
                    break
            
            report += f"| {company} | {tech_status} | {comm_status} | {cnpj_info} |\n"
        
        report += """
### Recomendação

Com base na análise dos documentos apresentados, recomenda-se uma avaliação mais detalhada considerando:

1. **Aderência ao TR**: Verificar se as propostas técnicas atendem todos os requisitos especificados
2. **Competitividade dos Preços**: Analisar a relação custo-benefício das propostas comerciais
3. **Qualificação da Equipe**: Avaliar a experiência e certificações dos profissionais propostos
4. **Cronograma**: Verificar a viabilidade dos prazos apresentados
5. **Saúde Financeira**: Consultar a situação das empresas junto aos órgãos competentes

"""
    
    report += """---
*Relatório gerado automaticamente pelo Proposal Analyzer Pro*
"""
    
    return report

if __name__ == '__main__':
    port = int(os.environ.get('PORT', 5000))
    app.run(host='0.0.0.0', port=port, debug=False)

