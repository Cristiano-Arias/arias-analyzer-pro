# Proposal Analyzer Pro

Sistema avançado para análise e comparação de propostas técnicas e comerciais.

## Funcionalidades

- ✅ Análise de Termo de Referência (TR)
- ✅ Análise de Propostas Técnicas (até 4 empresas)
- ✅ Análise de Propostas Comerciais (até 4 empresas)
- ✅ Geração de relatórios comparativos
- ✅ Download em formato Markdown e PDF
- ✅ Interface responsiva e moderna

## Tecnologias

- **Backend:** Python 3.11 + Flask
- **Frontend:** HTML5 + CSS3 + JavaScript
- **Processamento:** PyPDF2, python-docx
- **Deploy:** Render.com

## Deploy no Render

### 1. Preparação
- Conta criada no Render.com
- Código do projeto pronto

### 2. Configuração no Render
- **Runtime:** Python 3
- **Build Command:** `pip install -r requirements.txt`
- **Start Command:** `gunicorn app:app`
- **Environment:** Production

### 3. Variáveis de Ambiente
Nenhuma variável especial necessária para funcionamento básico.

### 4. Estrutura do Projeto
```
proposal-analyzer-render/
├── app.py              # Aplicação principal
├── requirements.txt    # Dependências Python
├── README.md          # Este arquivo
└── uploads/           # Diretório para uploads (criado automaticamente)
```

## Uso Local

```bash
# Instalar dependências
pip install -r requirements.txt

# Executar aplicação
python app.py
```

Acesse: http://localhost:5000

## Formatos Suportados

- **Documentos:** PDF, DOC, DOCX, PPT, PPTX
- **Planilhas:** XLS, XLSX
- **Compactados:** ZIP

## Limites

- **Tamanho máximo por arquivo:** 50MB
- **Propostas técnicas:** Máximo 4 empresas
- **Propostas comerciais:** Máximo 4 empresas

---

*Sistema desenvolvido para análise profissional de licitações e processos de concorrência.*

